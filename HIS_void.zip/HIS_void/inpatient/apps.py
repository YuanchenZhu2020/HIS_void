from django.apps import AppConfig


class InpatientConfig(AppConfig):
    name = 'inpatient'
