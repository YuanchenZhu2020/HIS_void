from django.apps import AppConfig


class ExternalapiConfig(AppConfig):
    name = 'externalapi'
