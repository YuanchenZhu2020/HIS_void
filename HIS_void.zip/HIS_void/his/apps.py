from django.apps import AppConfig


class HisConfig(AppConfig):
    name = 'his'
