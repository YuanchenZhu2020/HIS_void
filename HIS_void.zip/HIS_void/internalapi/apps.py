from django.apps import AppConfig


class InternalapiConfig(AppConfig):
    name = 'internalapi'
