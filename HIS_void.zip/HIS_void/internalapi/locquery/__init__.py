from .deptloc import DeptLocQuery

__all__ = [
    "DeptLocQuery"
]
