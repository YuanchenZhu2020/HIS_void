from django.apps import AppConfig


class OutpatientConfig(AppConfig):
    name = 'outpatient'
