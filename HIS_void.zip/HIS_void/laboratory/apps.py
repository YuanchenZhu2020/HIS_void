from django.apps import AppConfig


class LaboratoryConfig(AppConfig):
    name = 'laboratory'
